NVIDIA Corporation\NVSMI\nvml.dll

NVIDIA 430.86 driver version (non DCH)